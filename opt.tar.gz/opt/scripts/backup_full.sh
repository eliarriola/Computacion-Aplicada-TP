#!/bin/bash

# backup_full.sh - Script de backup con formato de nombre YYYMMDD

# Función de ayuda
mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo definiendo una ruta de origen y una ruta de destino: $0 /var/log /backup_dir"
    echo "Este script realiza un backup completo en formato tar.gz."
    echo "El archivo se guardará con el nombre: <nombre_dir>_bkp_YYYYMMDD.tar.gz"
}

# Validar argumentos
if [[ "$1" == "-help" ]] || [[ "$#" -ne 2 ]]; then
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar existencia de origen y destino
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está montado."
    exit 2
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está montado."
    exit 3
fi

# Crear nombre de archivo con fecha
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

# Realizar backup
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

# Verificar resultado
if [ $? -eq 0 ]; then
    echo "Backup exitoso: $ARCHIVO"
else
    echo "Error durante el backup."
    exit 4
fi

